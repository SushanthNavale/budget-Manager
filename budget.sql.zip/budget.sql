--
-- Database: `budget`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_name`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `admin_detail`
--

CREATE TABLE `admin_detail` (
  `img` blob NOT NULL,
  `name` varchar(20) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_detail`
--

INSERT INTO `admin_detail` (`img`, `name`, `contact`, `email`) VALUES
(0x6264312e6a7067, 'admin', '5555', 'admin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `bud_con`
--

CREATE TABLE `bud_con` (
  `ID` int(11) NOT NULL,
  `fac_name` varchar(25) NOT NULL,
  `dept_name` varchar(25) NOT NULL,
  `con_bud` varchar(25) NOT NULL,
  `details` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bud_con`
--

INSERT INTO `bud_con` (`ID`, `fac_name`, `dept_name`, `con_bud`, `details`) VALUES
(1, 'sushanth', 'workshop', '50000', ''),
(2, 'supreeth', 'Seminar', '45000', ''),
(3, 'ranadhir', 'Workshops And Seminars', '55000', ''),
(4, 'Ranjan', 'Books For Department Libr', '36000', ''),
(5, 'Ranjan', 'Books For Department Libr', '36000', ''),
(6, 'Ranjan', '', '38000', '  Books and magzine'),
(7, 'siddanth', 'Laptops OR Computers', '72000', '  desktops for labs and R&D Centers'),
(8, 'sush', 'R&D Work', '44000', '  Materials And hardware setup'),
(9, 'sushanth', 'Any Other Items', '14500', '  Sports items for practice for college tournament.'),
(10, 'sushanth', 'Any Other Items', '14500', '  Sports items for practice for college tournament.'),
(11, 'supreeth', 'Furnitures', '54000', ''),
(12, 'supreeth', 'R&D Work', '34500', '  research work '),
(13, 'supreeth', 'Books For Department Libr', '55500', '  books and magzines'),
(14, 'supreeth', 'Workshops And Seminars', '54000', '  workshops'),
(15, 'sushanth', 'Any Other Items', '20000', '  pizzas and burgers'),
(16, 'sushanth', 'R&D Work', '54500', '  references books and digital books');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `Name` varchar(30) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Mobileno` varchar(15) NOT NULL,
  `Query` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `Sl No` int(11) NOT NULL,
  `dept` varchar(40) NOT NULL,
  `bud` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`Sl No`, `dept`, `bud`) VALUES
(1, 'Permanent Equipement', '1'),
(2, 'Permanent Equipement', '1'),
(3, 'Faculty Development Program', '1,65,000');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `img` blob NOT NULL,
  `name` varchar(25) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`img`, `name`, `contact`, `email`) VALUES
('', 'Supreeth', '9945678923', 'superman@gmail.com'),
('', 'sushanth', '8095691761', 'navale1994@gmail.com'),
('', 'sushanth ', '8095691761', 'navale1994@gmail.com'),
(0x31312e6a7067, 'bike', '3564', 'nn@gmail.com'),
(0x62312e6a7067, 'hhn', '5698', 'hnn@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `name` varchar(40) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`name`, `dob`, `contact`, `email`) VALUES
('Mahalakshmi', '02-25-1979', '980075833', 'lakshmi@gmail.com'),
('dfgsd', 'gdsfgsdfg', 'dfgdfg', 'dfgdafg');

-- --------------------------------------------------------

--
-- Table structure for table `fac_bud`
--

CREATE TABLE `fac_bud` (
  `ID` int(11) NOT NULL,
  `fac_name` varchar(25) NOT NULL,
  `finan_year` varchar(25) NOT NULL,
  `dept_name` varchar(25) NOT NULL,
  `budget` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fac_bud`
--

INSERT INTO `fac_bud` (`ID`, `fac_name`, `finan_year`, `dept_name`, `budget`) VALUES
(1, 'sushanth', '', 'workshop', '30000'),
(2, 'sushanth', '', 'workshop', '30000'),
(3, 'supreeth', '', 'Seminar', '50000'),
(4, 'sushanth', '', 'softwares', '50000'),
(5, 'ranadhir', '', 'Workshops And Seminars', '60000'),
(6, 'ranadhir', '', 'Workshops And Seminars', '60000'),
(7, 'ranadhir', '', 'Workshops And Seminars', '60000'),
(8, 'ranadhir', '', 'Workshops And Seminars', '60000'),
(9, 'Ranjan', '', 'Books For Department Libr', '40000'),
(10, 'supreeth', '', 'R&D Work', '35000'),
(11, 'supreeth', '', 'Workshops And Seminars,An', '65000'),
(12, 'siddanth', '', 'Laptops OR Computers', '75000'),
(13, 'sush', '', 'R&D Work', '45000'),
(14, 'sushanth', '', 'Any Other Items', '15000'),
(15, 'sushanth', '', 'R&D Work', '10000'),
(16, 'supreeth', '2017-18', 'R&D Work', '50000'),
(17, 'supreeth', '2017', 'Furnitures', '55000'),
(18, 'supreeth', '2017-18', 'Books For Department Libr', '60000'),
(19, 'supreeth', '2017-2018', 'Workshops And Seminars', '55000'),
(20, 'sushanth', '2016-17', 'Any Other Items', '20000'),
(21, 'sushanth', '2017-18', 'R&D Work', '55000');

-- --------------------------------------------------------

--
-- Table structure for table `f_login`
--

CREATE TABLE `f_login` (
  `Faculty_ID` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `f_login`
--

INSERT INTO `f_login` (`Faculty_ID`, `fname`, `pass`) VALUES
(1, 'sushanth', 'faculty'),
(2, 'supreeth', 'faculty');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bud_con`
--
ALTER TABLE `bud_con`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`Sl No`);

--
-- Indexes for table `fac_bud`
--
ALTER TABLE `fac_bud`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `f_login`
--
ALTER TABLE `f_login`
  ADD PRIMARY KEY (`Faculty_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bud_con`
--
ALTER TABLE `bud_con`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `Sl No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `fac_bud`
--
ALTER TABLE `fac_bud`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `f_login`
--
ALTER TABLE `f_login`
  MODIFY `Faculty_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
